# Changelog

All notable changes to this project will be documented in this file.

This project follows Keep a Changelog.

## [0.15.2] - 2026-11-11

A second review of the whole source (correctness, memory, allocators, error handling), fixed.

### Changed

- `gates_node_create` makes plain nodes only (`CUSTOM`, `PANEL`, `SEPARATOR`); any other kind is
  `INVALID_ARG` and `*out_node` is `GATES_NODE_NULL`. A button, view, slider, spin box, group or
  editor made this way had no widget state, and the first layout, paint or key event dereferenced
  null; use the constructors (`gates_button_create`, ...), which attach it.
- `gates_sender_post` refuses a message kind from `0xFFFF0000` up (`INVALID_ARG`): those are the
  task code's own, and dispatch read their payload as a task record. A worker that posted one
  made dispatch follow an arbitrary pointer.
- The text box paths (`gates_textbox_set_text`, `replace_selection`, typing, paste, accessibility
  `SetValue`, `gates_text_edit_set_text`, `gates_text_edit_insert`) refuse malformed UTF-8
  (`INVALID_ARG`, the old text kept), as the editor already did; they stored it before.
- `gates_text_decode` follows one rule everywhere: an overlong form, a surrogate (`ED A0 80`) or a
  value past U+10FFFF is one byte of U+FFFD, as the header said. The editor, the encoding
  functions and the text box now use it through `gates_text_utf8_valid` (new, `gates/text.h`)
  instead of their own copies. The text module no longer includes the core's encoding header.
- Background task records (and their progress records) are allocated from the allocator the app
  gave its sender (thread-safe by contract; the proven heap by default), not always from the proven
  heap, so a counting or limiting host allocator sees them.
- The Win32 backend takes its own memory (the scratch run buffers, COM objects, thread boxes, the
  lock) from the proven heap allocator instead of `HeapAlloc`; the code-page conversions use the
  caller's allocator for their scratch buffer too. The run buffers of text drawing are kept between
  calls instead of two heap allocations per drawn run.
- `gates_undo_create` and `gates_text_buffer_create` treat an allocator with a missing function
  like the other creators do (the proven heap); one with `alloc_fn` set and `free_fn` null
  crashed at destroy.
- Line numbers in the editor and the window placement string are formatted with `proven_fmt_to`
  (checked, bounded) instead of `snprintf`; the proven fmt, string and buffer code joins the
  libraries.

### Fixed

- `draw_line` walked the whole line even when most of it lay outside the clip: a line from
  (-2e9, -2e9) to (2e9, 2e9) took billions of steps and froze the window; its error terms also
  overflowed past 2^30. A line is now clipped by arithmetic (the same pixels as the plain walk;
  checked against it on thousands of random lines) and costs only the pixels it can show.
- Windows: text drawing handled at most 4096 device pixels of a run and dropped the rest (a long
  line scrolled sideways, a window wider than 4096 pixels). The visible part is drawn in strips,
  and only the units that reach each strip go to GDI.
- Windows: a lone high surrogate from `WM_CHAR` waited for any later low surrogate and made a
  bogus character with it; it is dropped when another character arrives first.
- Windows: an IME result the editor refused (a limit, bad text) now reaches `on_input_error`; the
  editor's commit left no error behind for a refused text.
- The editor's undo history could grow one entry past its budget in a single long typing or
  deleting run, and was never trimmed; a run now ends its entry at a quarter of the budget, and
  the history is trimmed after every join.
- A replaceable post scanned the whole queue under the sender's lock; the queue counts its
  replaceable messages and the scan goes newest first and stops at the last of them.
- The colour dialog loaded `comdlg32.dll` on every call and never let it go; it is loaded once.

## [0.15.1] - 2026-11-11

### Fixed

- Windows clipboard line ends: copy writes a line feed as CR LF and paste reads CR LF as a line
  feed. Programs that insist on CR LF (classic Notepad) showed a copied multi-line text as one
  line; a text copied from one and pasted into gates kept the CRs. (RFC-0009 R9-07.)

## [0.15.0] - 2026-11-11

A whole-source review (security, memory, undefined behaviour, logic), fixed.

### Fixed

- Destroying a subtree that owns an open menu (its commands live in it) could write past the end of
  the list of destroyed nodes when the subtree's size plus the menu's filled the list exactly: a heap
  overflow of a few bytes. The list is now threaded through the nodes themselves, allocates nothing
  and cannot fail (`gates_node_destroy` no longer returns NOMEM). Found by fuzzing under injected
  allocation failures.
- A log view reserved memory for its whole `max_lines` at creation (4 billion lines asked for
  100 GB); it now starts small and grows with the lines, up to the limit.
- Closing a window while a background task had finished but the message queue was full no longer
  hangs: `gates_tree_destroy` told the worker nobody listens, it lets go of its end and the join
  returns. (It used to wait for ever; found by reading the task protocol.)
- Ranges that span all of 64 bits: stepping, paging, the default page (ten steps), the thumb's
  place and a drag to the end no longer overflow. A slider over `INT64_MIN..INT64_MAX` shows its
  thumb where the value is and a drag reaches both ends.
- A slider with ticks on every step of a huge range emitted a draw command per step (billions; for
  `0..INT64_MAX` the loop never ended). Ticks closer than a pixel are not drawn now.
- A wheel amount that is NaN, infinite or far beyond the integers no longer reaches an integer
  conversion (undefined behaviour in C): NaN moves nothing, anything else is held to 1000 notches.
- Numbers at the edge of 32 bits - a viewport, an absolute rectangle, a scroll offset, a column
  width, the position of a menu or pointer - no longer overflow inside layout, painting and
  rendering (about forty places in all).
- Deferred calls (`gates_tree_defer`) asked for while a run is in progress wait for the next run,
  as documented, also when a call of the run cancels others.
- Size hints that are unsigned and huge (`cols` of a text box or editor, `rows`, the tab width) are
  held, and `gates_access_at_point`, `_cell_at` and `_text_offset_at` hold their points like the
  pointer calls do.
- The null pointer of an empty text no longer has zero added to it (eight places and the
  encoding stream); clang's sanitizer reports that, gcc's does not.

### Changed

- `gates_layout_set_padding` and `gates_layout_set_gap` refuse more than `GATES_EXTENT_MAX`
  (65,536) with `INVALID_ARG`, as they already did for a negative number; column widths are held
  to it. A viewport, absolute rectangle, scroll offset, menu position and pointer position are held
  to +-`GATES_COORD_MAX` (16,777,216). Both constants are in `gates/geometry.h`.
- Build: `make ubsan` runs the whole suite under clang with address, undefined-behaviour and
  float-conversion checks; it is part of the release gate. The suite gained `test_hardening`.
- The vendored proven_c_lib is v0.113.0 (was v0.6.0); no gates source needed changing for it.

## [0.14.0] - 2026-10-03

A toolbar no longer reads as another row of tabs.

### Changed

- Toolbars: a line under the band, button boxes above it; a button that is on (a checked
  command) has the accent border instead of looking like a selected tab.
- Tabs: the page is framed on its other three sides and the selected tab opens into it with the
  accent along its top; the other tabs are outlines (they were filled like buttons). A text-only
  toolbar right above tabs - two rows of short words - looked alike before.

## [0.13.0] - 2026-10-02

The pointer shows what a press will do.

### Added

- `gates_cursor_at()` and `gates_cursor_t`: the pointer's shape over a point - resize arrows over a
  table's column edge and a side-by-side split's handle (left-right) or a stacked split's handle
  (up-down), the text beam over a text box and an editor's text, the arrow elsewhere, over disabled
  controls and over what a modal dialog covers. A drag keeps its shape wherever the pointer goes.
- Win32 windows set the pointer from it (WM_SETCURSOR); before, it was always the arrow.

## [0.12.0] - 2026-10-02

Fonts by name: one face for the whole program, at creation or while it runs, or a face per element.

### Added

- `gates_app_desc_t.ui_font`: the face of `GATES_FONT_UI` chosen by the program (UTF-8, such as
  "Malgun Gothic"), at the platform's UI size. Empty keeps the system message font; a face that is
  not installed falls back to it.
- `gates_app_set_ui_font()`: the same while running (a settings screen's font choice); every window
  lays out again. `PROVEN_ERR_NOT_FOUND` when the face is not installed.
- Named faces per element: `gates_font_named()` registers a face name and returns a face that
  `gates_node_set_font()` takes like `GATES_FONT_MONO` - on one node, an area, or the root for the
  whole window; inherited and sized like the others. `gates_font_face_name()` gives a backend the
  name. The Win32 backend draws the face at the UI size (the UI face when it is not installed);
  the builtin backend has one face.

## [0.11.0] - 2026-10-02

A built-in CP949/EUC-KR converter, conversion without allocation, UTF-8 command lines and console
on Windows, and a round of backlog work. proven_c_lib is vendored at v0.6.0.

### Added

- `gates_codepage_converter_cp949()`: a converter for code pages 949 (CP949) and 51949 (EUC-KR)
  for targets without an OS, from tables measured on Windows 11 (decoding and encoding checked
  against Windows code by code; Windows' one-way quirks are refused, and 51949's B4D3 follows
  KS X 1001). Linked only into programs that call it.
- Text conversion without allocation for the UTF forms: `gates_encoding_to_utf8_buf` /
  `_from_utf8_buf` into a caller's buffer (with a size query), and `gates_encoding_stream_t`,
  which converts in pieces and carries a character cut at a piece's end.
- `gates_args_split` (a command line by the Windows rules), `gates_args_utf8_win32` (this
  process's arguments as UTF-8) and `gates_console_write_win32` (UTF-8 to the console, or the
  bytes to a redirect).
- Saved state keeps a scroll area's sideways offset ("y,x").
- Menus without an explicit name are named by their menu bar title, the entry that opened them, or
  the node focused when the program opened them; UIA raises MenuClosed.

### Changed

- A view's accessibility items include its selected row wherever it is (first above the shown
  rows, last below), so UIA Selection finds it after scrolling away.
- Type-ahead searches the current column, else the first shown one.
- proven_c_lib v0.6.0 (was v0.1.1); no gates source needed changing.

### Fixed

- Win32: a fourth quick press is reported as 4 (it was 2: Windows pairs presses into double
  clicks).
- Win32: a change of the system's UI font takes effect at once (it needed a restart).

## [0.10.0] - 2026-10-01

Submenus, tab overflow, cells and tooltips for screen readers, sideways scrolling, font sizes,
icon pixel sets, a selection store, text encodings, an API reference and the manual as a book.

### Added

- Menus: submenus (`gates_command_set_submenu`): opened by hovering (GATES_MENU_SUB_DELAY_MS), by
  Right, Enter or Space; Left closes one; choosing an entry closes the whole chain; in a menu bar
  Left/Right still switch titles. The gallery's View menu has a Theme submenu.
- Tabs: titles that do not fit - the strip shows whole titles, always the selected one, and a
  ">>" button (or Alt+Down on the strip) opens a list of every tab; screen readers see it as a
  "More tabs" button.
- Accessibility: the shown tooltip is an element of its own (role TOOLTIP, UIA ToolTip, announced
  when it opens); table cells are elements a level below their rows (`gates_access_cell_count`,
  `_cell_at`, `_cell_info`, `_cell_toggle`, `_cell_set_value`; UIA GridItem, Toggle, Value,
  RangeValue) and tables scroll sideways for assistive technology (`gates_access_hscroll_info` /
  `_hscroll_to`).
- Scroll areas can scroll sideways too (`gates_layout_set_scroll_sideways`, `_set_scroll_x`):
  a bottom bar, the wheel's sideways motion (Shift+wheel), focus into view across.
- Font sizes per node in percent of the system's text size (`gates_node_set_font_size`;
  GATES_FONT_SIZE_SMALL, _LARGE, _HEADING), inherited separately from the face; a font value
  carries its size (`gates_font_sized`, `gates_font_face`, `gates_font_percent`).
- Images hold pixel sets for other scales (`gates_image_add_variant_rgba`, `_load_variant_file` /
  `_memory`): the renderer draws the smallest set that covers the device pixels, so icons stay
  sharp at 150 % and 200 %. The gallery's icons carry 24- and 32-pixel sets.
- A selection store for multi-select views (`gates_selection_t`: ranges of rows, requests in rows,
  rows inserted and removed) and `gates_view_apply_selection`; dragging over rows selects them.
- Text encodings at the edge (`gates/encoding.h`): UTF-8, UTF-16 and UTF-32 to and from UTF-8 on
  every platform, Windows code pages (949, 51949, the system's, ...) through the platform's
  converter (installed by the Win32 app), replacement or strict refusal with a byte offset, and
  a guess for bytes of unknown origin.
- Manual chapter 14, the API reference: every public function with its header's comment, made from
  the headers (`tests/api_reference.sh`); `make manual-check` fails on an undocumented public
  function or a stale chapter. The manual as a book: a PDF of the guide and a web edition of
  everything (`make manual-book`), attached to the release.

### Changed

- Hit testing finds a scroll area's children only inside its viewport (not under its bars or in
  its padding).
- View and editor row geometry for hit testing uses the node's line height from the text
  backend, as painting always did.
- The GDI text backend keeps fallback fonts per face and size.

### Fixed

- A node created in a destroyed scroll area's slot no longer inherits its sideways scrolling.
- A table cell no longer reports its row's keyboard focus to UI Automation.

## [0.9.0] - 2026-09-30

Multi-selection, growing posting queues, and a public specification.

### Added

- Views: multi-selection owned by the model (`gates_view_desc_t.multi_select`, the model's
  `next_selected`): gestures arrive as GATES_EVENT_SELECT_REQUESTED (ONE, TOGGLE, RANGE,
  ADD_RANGE, ALL; `ev->item` the target, `ev->anchor` the anchor) for the program to apply; Shift
  and Ctrl with clicks and keys, Ctrl+A, Ctrl+Space; Ctrl+C copies up to GATES_VIEW_COPY_MAX rows,
  past that GATES_EVENT_COPY_REQUESTED. gates asks only about rows it paints, describes or copies.
- Accessibility: GATES_ACCESS_MULTISELECT, `gates_access_set_item_selected`; UIA
  CanSelectMultiple, GetSelection, AddToSelection and RemoveFromSelection for such views.
- `spec/spec.md`: what gates guarantees, in one document (also in the package).
- `gates_sender_capacity`; manual chapter 5 section on multi-selection (ex_05_multi: a million
  rows kept as ranges); the gallery's Views table selects many rows.

### Changed

- Posting queues start with GATES_POST_INITIAL_MESSAGES (256) slots and grow on the UI thread,
  doubling up to `max_messages`, as posts fill them; posting still never allocates. Limits and
  defaults are unchanged.
- Code comments and CHANGELOG no longer cite private design documents.

## [0.8.0] - 2026-09-30

Backlog follow-ups across input, controls and the Windows backend.

### Added

- Pointer events carry the modifier keys (`shift`, `ctrl`, `alt` in `gates_pointer_event_t`);
  Windows fills them and reports a third quick press as `clicks` 3.
- Text boxes and the editor: Shift+click extends the selection, a double click selects a word
  and a triple click selects all (text box) or the line with its break (editor).
- Editor with wrap: Home and End go to the row's start and end before the line's, and a caret at
  a row's end stays drawn there (Up/Down into a shorter row, End, a press right of a row).
- `gates_access_text_line`: the shown row holding an offset; the Windows UIA Line unit follows
  wrapped rows (Paragraph stays the text line).
- Spin boxes: an arrow held down repeats after a pause while the pointer stays on it; the wheel
  steps a focused spin box or slider (unfocused, it scrolls the page).
- `gates_layout_set_grid_row_grow`: spare height to GRID rows by weight (the first
  `GATES_GRID_MAX_GROW_ROWS`).
- Access info carries `range_step`, `range_page` and `range_scale`; UIA RangeValue reads a
  scaled spin box as shown (1.25) with the step and page as small and large change.
- Views: type-ahead (the next row whose first shown cell starts with the letters typed), Ctrl+C
  copies the selected row's shown cells (tab-separated), and a current column (Ctrl+Left/Right
  or the cell pressed, outlined) that F2 and Space use.
- Log views report GATES_EVENT_FOLLOW_CHANGED when a person's scrolling starts or stops
  following; ctl_log and app_logview use it.
- `gates_window_open_files`: several files from one open dialog (the gallery's Pictures page).
- Window callbacks gain `on_input_error`, called with `gates_input_take_error` after each input
  turn; the reference applications show it.
- A press on a scroll area's track pages it.

### Changed

- A FORM that stacks its rows (narrow) measures the stacked height, so what follows it is no
  longer covered (a second layout pass when stacking changes, as for WRAP).
- Menu separators are short rows; hit testing and accessibility rectangles follow them.
- Windows: a window is shown when `gates_app_run` starts, so its first frame already has the
  program's UI; leftover events continue on a timer instead of a self-posted message.
- app_settings: the required-field progress bar became an applying step that animates, or not
  when Windows is set to reduce motion.
- Examples compare handles with `gates_node_eq`; code comments are ASCII.

### Fixed

- The UIA RangeValue change event of a spin box reported the value minus the minimum.

## [0.7.0] - 2026-09-30

The multi-line editor.

### Added

- Text buffer (`gates/text_buffer.h`): UTF-8 in a gap buffer whose reads never move the gap (a
  range is at most two spans), a line index with a pending shift, a style byte per byte, marks
  with gravity, and find (forward, backward, ASCII case).
- Multi-line editor (`gates/editor.h`): one node over a text buffer that paints only the lines it
  shows; keys by code point, word, line and page with smart Home; pointer caret, drag selection,
  double click word, wheel and scrollbars; clipboard keeping line breaks and tabs; read-only and a
  byte limit; undo with typing and deletion runs and a modified mark; program edits; events
  (TEXT_CHANGED without a text copy, SELECTION_CHANGED with the caret).
- Editor options: soft wrap (Up/Down by rows), a line number gutter, auto-indent, and when Tab
  types tabs, Tab/Shift+Tab indenting selected lines with Ctrl+Tab leaving; `gates_editor_set_wrap`
  and `_set_line_numbers` change them later.
- Highlighting: a style table and a lazy styler asked only for stale lines about to show; program
  styles; marks and find through the editor.
- Input methods compose at the caret in the editor (drawn underlined; the result is one edit).
- Accessibility by line: `gates_access_text_rects` (one rectangle per row), offsets, selection and
  value for the editor; Win32 UIA Line and Paragraph units and multi-row bounding rectangles.
- Manual chapter 6: the editor, highlighting and large texts (ex_06_editor, ex_06_highlight); the
  gallery's Text editor page (Alt+X).

### Changed

- The Windows IME is detached while a read-only editor has focus, as for read-only text boxes.

## [0.6.0] - 2026-09-30

Data controls.

### Added

- Views: cell kinds (`gates_column_desc_t.kind`: check box, progress bar, icon and text) and
  custom cell painting (`paint`, `gates_cell_paint_t`); editable columns with in-place editing
  (F2, double click, Enter, Escape, focus leaving commits; Space or a click toggles a check
  column) through the model's new optional `set_cell`; `gates_view_edit`, `_end_edit`,
  `_editing`, `_editor`; GATES_EVENT_CELL_EDITED (row in ev->item, column in ev->result).
- Views: hide, show and reorder columns (`gates_view_set_column_hidden`, `_column_hidden`,
  `_move_column`, `_column_at`); a header menu (`column_menu`: right press on the header or
  Shift+F10, `gates_view_open_column_menu`).
- Property grid (`gates/propgrid.h`): typed fields (text, bool, choice, number) by stable id in
  collapsible categories, built from the ordinary editors; one handler hears every change
  (VALUE_CHANGED with the property id).
- Undo stack (`gates/undo.h`): entries with undo/redo functions and labels, merge runs, a bound,
  a clean mark, and two commands kept in step ("Undo Rename").
- Background tasks (`gates/task.h`): work on a platform thread with progress (the latest report
  wins), a result, cancellation and one on_done on the UI thread; closing the window cancels and
  joins its tasks. The Win32 window supplies the threads. Message kinds from 0xFFFF0000 up are
  reserved for them.
- Manual: chapter 4 (undo), chapter 5 (cells people change, the property grid), chapter 7
  (background tasks).
- The gallery's Data & jobs page (an editable table, a property grid, Edit > Undo/Redo and
  Columns, a background job with Cancel); app_inspector renames records in place.

### Changed

- Saved state lines for tables carry column ids, order and hidden marks
  ("columns 5:80,1:150,3:120h ..."); the widths-only form still loads.
- The Text page of the gallery labels its second field "E&mail" (Alt+E opens the new Edit menu).

### Fixed

- A label, button, check box, text box, image, tab page, menu bar, toolbar or status bar whose
  creation failed for lack of memory could stay in the tree, and the rollback flushed other
  pending destroys.
- Commands whose scope node is destroyed are freed with it (a closed dialog no longer keeps its
  command slots until the tree is destroyed).

## [0.5.0] - 2026-09-29

Images and native dialogs.

### Added

- Images (`gates/image.h`): a tree's image store (RGBA8 in, ids never reused), a decoder seam
  (`gates_tree_set_image_decoder`, `gates_image_load_file` / `_memory`), the IMAGE draw command
  (`gates_draw_image`, bilinear, alpha), the image node (natural or fixed size, aspect kept;
  Image role when named), icons on buttons, commands (menus, toolbars) and icons-only toolbars.
- Manual chapter 13.
- Windows: images decode through Windows Imaging Component (PNG, JPEG, BMP, GIF, ICO, TIFF);
  `gates_window_open_file`, `gates_window_save_file`, `gates_window_choose_folder`,
  `gates_window_choose_color` and `gates_window_message` show the platform's dialogs. Both are
  reached at run time: the link line is unchanged.
- The gallery's Pictures page (a picture, toolbar icons, every native dialog).

### Changed

- The IMAGE draw command, reserved until now, draws images; `gates_draw_cmd_t` has a new
  `image` field.

## [0.4.0] - 2026-09-29

Input controls and plumbing.

### Added

- Event bubbling: `gates_node_set_bubble_handler` on any node hears the events of descendants
  without a handler of their own (the nearest such ancestor; never across an overlay root).
- Deferred calls: `gates_tree_defer` / `gates_tree_cancel_defer` run a function once at the next
  safe point (after the queued events), one call per key.
- Spin box and slider (`gates/inputs.h`): an integer range with step, page and a decimal scale;
  VALUE_CHANGED with `ev->value` (new field); `gates_range_format` / `gates_range_parse`;
  `gates_access_set_range_value`; UIA Spinner and Slider with a settable RangeValue.
- Manual chapter 12 (numbers, groups and layouts).
- Group box (`gates_group_create`, collapsible with VALUE_CHANGED), GRID layout (columns, grow
  weights, spans) and WRAP layout (a second layout pass when a wrap container's width changes).
- Examples: the gallery has an Inputs page (spin boxes, a slider, a collapsible group in a grid,
  wrapped chips, a total recomputed once per turn); the calculator uses one bubble handler for
  its twenty keys.

### Changed

- `gates_event_t` has a new field `value` (a spin box's or slider's value).

## [0.3.0] - 2026-09-29

The application frame: menu bar, toolbar, status bar, tabs, tooltips,
mnemonics, a keymap and saved UI arrangement.

### Added

- `gates/frame.h`. Mnemonics: `&x` in button, check box, command, menu bar and tab texts
  (labels given a target with `gates_label_set_target`) marks an Alt+x access key, underlined
  while keyboard cues are visible; duplicates cycle the focus. `gates_input_mnemonic`,
  `gates_input_menu_key`, `gates_input_show_cues` and `gates_tree_set_cues_always` for
  platform code.
- Menu bar (`gates_menubar_create`, `gates_menubar_add`): command menus with menu mode (F10 or
  Alt alone, arrows, letters, Escape back to the title), the existing menu overlays.
- Toolbar (`gates_toolbar_create`, `gates_toolbar_add`): command buttons, checked commands
  shown pressed, one Tab stop, clicks that keep the focus where it was, a `>>` overflow menu.
- Status bar (`gates_statusbar_create`, `gates_statusbar_add`): label segments with
  separators.
- Tooltips (`gates_node_set_tooltip`): after 500 ms of hover or keyboard focus, hidden by
  presses, keys, leaving and time; toolbar buttons show their command's label and shortcut.
  Read by screen readers as help text. No timer runs while nothing with a tooltip is hovered.
- Tabs (`gates_tabs_create`, `gates_tabs_add`, ...): a strip over pages, arrows,
  Ctrl+Tab / Ctrl+PgUp / Ctrl+PgDn, mnemonics, the focus following into the new page,
  VALUE_CHANGED with the new index.
- Keymap in `gates/command.h`: `gates_command_set_shortcut` (with conflict report),
  `gates_command_shortcut`, `gates_command_count` / `gates_command_at`,
  `gates_shortcut_format` and `gates_shortcut_parse`.
- `gates/state.h`: `gates_state_save` / `gates_state_load` keep split ratios, selected tabs,
  column widths and scroll offsets of nodes with automation ids as tolerant text. Windows:
  `gates_window_placement` / `gates_window_set_placement`.
- Accessibility: MenuBar, ToolBar, StatusBar, Tab and TabItem roles; `access_key` ("Alt+F")
  and `accelerator` ("Ctrl+N") in `gates_access_info_t`, exposed as UIA AccessKey and
  AcceleratorKey.
- Example `gallery` (every control and the frame, theme and zoom commands, saved arrangement);
  manual chapter 11 in English and Korean.
- `make bench`: a core benchmark (tests/bench_core.c) - cold start, layout, paint walk,
  software rendering at 96, 144 and 288 dpi, keystroke and scroll to frame, memory split into
  UI-owned, model-owned and frame scratch bytes, model calls per frame for a 100 000-row table,
  and latency of a 200 000-message post flood. It measures; it does not assert.
- Windows: `GATES_PERF=<file>` in the environment appends one line per frame (input to
  present, layout, paint, render and present times, size, dpi, command count), per wake
  (timer, dispatch, post) and the first frame's time since process start. Off (and free)
  without the variable.

### Changed

- In button, check box and command labels `&` before a letter or digit is now a mnemonic and is
  not shown (write `&&` for a literal one); any other `&` is shown as before.
- After a menu takes a key, the character that key makes is no longer typed into the control
  below it (choosing an entry with Space used to type a space).
- Windows: Alt+letter reaches gates through WM_SYSCHAR only when it matches a mnemonic; Alt
  alone and F10 enter menu mode when the window has a menu bar. The pointer leaving the window
  now ends hover.

### Fixed

- Text boxes, choices and very short buttons are at least 24 units in each direction again: with
  the Windows UI font (a 15-unit line, since 0.2.0) they were 23 high, below the WCAG 2.5.8
  target that `gates_access_audit` enforces.
- `make win` rebuilds the Windows programs when a header changes (the version number did not
  reach them before).

## [0.2.0] - 2026-09-27

Proportional text: the monospace restriction is lifted.

### Changed (breaking for custom text backends)

- The text backend contract: a backend reports the advance of every code point
  (`glyph_advance`, required) and a string is exactly as wide as the sum of its code points'
  advances - no kerning, ligatures or shaping, so the caret, selections and hit testing stay
  exact. The `font_size` parameters of `metrics`, `measure`, `draw` and `draw_scaled` (and
  `gates_draw_text`, `gates_draw_cmd_t.font_size`) become a font (`gates_font_t`, same integer
  type; no public API could set a size). `gates_text_metrics_t.advance` is now the average
  character width, a sizing hint (a text box's `cols`).
- Windows: text uses the system UI font (Segoe UI, Malgun Gothic on Korean Windows) and is
  proportional by default; characters the face lacks come from the system's fallback fonts.
  Controls sized by their text become narrower.
- A click in a text box puts the caret at the nearest character boundary (it used to take the
  cell under the pointer).

### Added

- Fonts: `GATES_FONT_UI` (proportional, the default) and `GATES_FONT_MONO` (fixed pitch,
  Consolas on Windows), chosen per node with `gates_node_set_font` and inherited like CSS
  `font-family` (`GATES_FONT_INHERIT`, `gates_node_font`).
- `gates_text_width` and `gates_text_offset_at_x`: widths and positions from the advances.
- The log views of `ctl_log` and `app_logview` and a panel of `text_demo` use the mono font.

### Unchanged

- The builtin backend stays fixed-pitch (8 per narrow, 16 per wide character) for both fonts:
  the deterministic reference for tests and pixel-exact output.

## [0.1.0] - 2026-09-27

The first package: headers and static libraries a program builds against.
Source compatible within 0.1.x; rebuild on every update; no binary ABI is promised yet.

### Added (package and manual)

- The package: `make dist` builds `dist/gates-0.1.0/` - public headers, the proven headers they need, static libraries (`lib/win64/libgates.a`, `lib/host/libgates_core.a`, and `libproven.a` for each, separate from gates), licenses, the manual and `examples/consumer/`, a program built from the package alone; `make install PREFIX=...`. `gates/version.h` (`GATES_VERSION_*`, `gates_version()`, `gates_version_string()`) and `gates/gates.h`, which includes the whole public API. The libraries export only `gates_*` / `proven_*` names.
- Sample applications `app_todo`, `app_calculator`, `app_converter` and `app_files` (examples/), shipped with every other example as Windows 11 x64 binaries in the release.
- A live label no longer re-announces (or re-lays out) when it is given the text it already shows.
- The manual, in English (`manual/`, canonical) and Korean (`manual-ko/`): eleven chapters from the first program to deployment and troubleshooting; every program it prints is compiled against the package, and the headless ones run (`make manual-check`).

### Changed (breaking)

- Pointer targets are at least 24 x 24 units (WCAG 2.2 2.5.8): radio rows, menu and list rows, view rows and checkboxes are taller when the text line is shorter than that.

- Every coordinate and size the API takes or returns is now a logical unit, 1/96 inch: layout values, node rects, preferred sizes, view part rects, window sizes, pointer positions and the viewport given to `gates_layout_run`. A window scales once at its boundary - drawing goes to device pixels, pointer positions come back in units - so on displays above 100% applications grow with the scale; at 100% nothing changes. `gates_pointer_event_t.screen_pos` stays in device pixels.

### Added

- Accessibility: `include/gates/access.h`. Every node has a role, a name (explicit `gates_node_set_access_name`, a tied label `gates_node_set_labelled_by`, a form field's label, or its own text), a description (a field's error and help), states, a value, bounds and the actions it accepts, and radio options, choice options and menu entries are virtual items addressed by id; `gates_access_info`, the accessible tree (`gates_access_parent` / `_first_child` / `_last_child` / `_next` / `_prev` / `_at_point` / `_focus_ref`), actions that take the same paths as input (`gates_access_invoke` / `_toggle` / `_select` / `_expand` / `_set_value` / `_focus`), a change log for platform adapters, live regions (`gates_node_set_live`), announcements, stable automation ids (`gates_node_set_automation_id`; forms and commands give `field-<id>` and `cmd-<id>`), and an audit of enforced rules (`gates_access_audit`, `gates_theme_audit`: names, 24 x 24 targets, keyboard reach, duplicate ids, contrast, focus cues).
- Accessibility: views expose their shown rows (and the selection) as items - list items, table rows named by their cells, tree items with level, expanded state and loading rows - with select, invoke (as Enter) and expand-as-request through the model; `gates_access_scroll_info` / `_scroll_to` / `_scroll_by` for views and scroll areas; text of edits for text APIs (`gates_access_text_rect`, `_text_offset_at`, `_select_text`); `set_position`, `set_size` and `level` in the info.
- Windows: every window is a UI Automation provider written in C (Invoke, Toggle, Value, RangeValue, Selection, SelectionItem, ExpandCollapse, Grid, GridItem, Scroll, Window for dialogs, Text and Text2 for edits with UTF-16 offsets; focus, property, structure, live-region, menu-opened, text-changed, text-selection-changed and notification events), so Narrator and automation tools see the tree; a hidden system caret follows the text caret for magnifiers; `gates_window_set_zoom` / `gates_window_zoom` and the Windows "Text size" setting scale the whole window; `gates_window_reduced_motion`; `gates_window_announce`; `GATES_ACCESS_STRICT=1` audits after every layout and shows the issue count in the title. Links `uiautomationcore`, `ole32`, `oleaut32`, `uuid`; the UI thread is initialised as a COM single-threaded apartment. `widgets_demo`: F3 / F4 zoom. The examples name every control.

- Themes: `gates_theme_dark()`, `gates_theme_high_contrast()` from the system's colours, focus and error cue widths in `gates_theme_t`; windows follow the system (dark mode, high contrast, live) unless the application picks a mode or theme (`gates_window_set_theme_mode`, `gates_window_set_theme`, `gates_window_theme`); the title bar follows dark mode. The light palette's disabled text is darker (3:1 contrast).
- DPI: per-monitor DPI awareness, `WM_DPICHANGED` handling, logical-unit helpers `gates_px`, `gates_logical`, `gates_rect_px`, `gates_thickness_px`, `gates_render_soft_scaled`, and an optional `draw_scaled` for text backends (the GDI backend draws crisp scaled glyphs on the scaled cell grid). `GATES_FORCE_DPI` forces a DPI for diagnostics. `widgets_demo`: F2 cycles the theme mode.

- Posting from worker threads: `include/gates/post.h`. A reference-counted sender (`gates_app_sender`, `gates_sender_retain` / `_release`) outlives the app; `gates_sender_post` never blocks or allocates and answers `GATES_POST_FULL` or `GATES_POST_CLOSED` (the caller keeps the payload), otherwise gates owns the payload and releases it exactly once - after delivery to the target node's handler (`gates_node_set_message_handler`), when the target is gone, when a replaceable snapshot replaces it, or at shutdown. Targets name a tree by its process-unique serial (`gates_tree_serial`, `gates_target`). Delivery is bounded per turn (64). Queue limits in `gates_app_desc_t` (defaults 1024 messages / 1 MiB). The core stays thread-free: the platform supplies the lock and the wake-up (`gates_sync_t`, `gates_sender_create`).
- Timers: `include/gates/timer.h` - `gates_timer_start` / `_cancel` / `_active` on a node; cancel is immediate, node or tree destruction cancels, a late repeating timer fires once. Win32 keeps one SetTimer per window for the next due timer (none when idle).
- `app_logview` now reads from a real worker thread (skips batches on FULL, ends on CLOSED, keeps input responsive while flooding); `ctl_progress` has a timer-driven "run".

- Virtual views: `include/gates/view.h`. A list or table is one node over a model the application owns (`gates_rows_model_t`: count, id_at, index_of, cell, optional revision and row_info) and asks only for the rows it paints (at most `GATES_VIEW_MAX_ROWS`); rows are 64-bit and the vertical position is kept in rows; the single selection is a stable item id that survives inserts, removals and reordering (`gates_view_model_changed` moves a vanished selection to its nearest neighbour and announces it with origin PROGRAM). Keyboard (arrows, PageUp/PageDown, Home/End, Enter), click and double click, wheel and Shift+wheel, both scrollbars, header clicks as sort requests, column resizing with minima. Trees: flattened visible rows with depth and open state, open/close as requests, Left/Right navigation, loading and error rows. Logs: `gates_log_create` / `_append` / `_clear` / `_line` / `_following` with line and byte limits, counted drops and follow-at-end. Events SELECTION_CHANGED, SORT_REQUESTED, EXPAND_REQUESTED and ACTIVATED with `ev->item`. Examples `ctl_list`, `ctl_table`, `ctl_tree`, `ctl_log` and reference applications `app_inspector` and `app_logview`.
- Input: `GATES_KEY_PAGE_UP` / `_PAGE_DOWN` and `gates_pointer_event_t.clicks`; the Win32 window class has CS_DBLCLKS, double clicks arrive with `clicks = 2`, and Shift+wheel scrolls sideways.

- Forms: layout kind `GATES_LAYOUT_KIND_FORM` (one label column, labels above editors when the form is narrower than the label column plus 12 cells, hidden rows take no space) and `include/gates/form.h` (`gates_form_create`, `gates_form_add_text` / `_checkbox` / `_choice` / `_radio` with label, help, required marker and read-only, `gates_form_set_error`, lookups by field id, `gates_form_set_row_hidden`); node kind FORM. Rows are built completely before they are attached. Reference application `app_settings`.
- Fields: radio group and choice (dropdown) as single nodes with stable option ids (`gates_option_t`, `gates_radio_create`, `gates_choice_create`, `gates_options_set` / `_set_selected` / `_selected` / `_set_enabled` / `_count`, `gates_choice_list` / `_list_open`); VALUE_CHANGED carries the selected id in `ev->result`; the choice's list is an overlay with the menu's rules and opens with Space, Enter, Alt+Down or a click. Separator (`gates_separator_create`) and progress bar (`gates_progress_create` / `_set_value` / `_value`, per-mille). Hidden nodes (`gates_node_set_hidden` / `gates_node_hidden`) for layout, paint, hit testing and focus. Textbox error state (`gates_textbox_set_invalid`) and theme token `GATES_COLOR_ERROR`. `GATES_STR_INIT` for static option tables. Examples `ctl_radio`, `ctl_choice`, `ctl_progress`.

### Fixed

- Win32: Alt+Up and Alt+Down now reach the widget tree (they were handed to Windows with every other Alt combination); unused, they still go to Windows.

- Overlays: `include/gates/overlay.h` with modal dialogs (`gates_dialog_open` / `_close`, DIALOG_CLOSED once, focus scope, dimmed and blocked content behind, focus restored, any press or drag below cancelled) and context menus of commands (`gates_menu_open` / `_close`, MENU_CLOSED, keyboard navigation, outside click only closes, closed on window focus loss); node kinds DIALOG and MENU; theme token OVERLAY_DIM. Examples `ctl_dialog` and the context menu in `ctl_commands` (right-click or Shift+F10).

- Keyboard focus: buttons and checkboxes are focusable and draw a focus ring; Tab / Shift+Tab traversal in tree order with wrap (`gates_tree_focus_next`), `gates_widget_set_focusable`, focus repair when the focused control is disabled, hidden or destroyed, scroll-to-focus; Space activates on release, Enter activates a focused button, Escape cancels a press.
- Command model `include/gates/command.h`: registration per scope, shortcuts (Ctrl+key or F1-F12), default/cancel roles for Enter/Escape, enabled/checked/label state, `gates_command_invoke`, `gates_button_set_command`; invocations are queued and re-checked before running.
- Key events carry `letter`; new keys SPACE and F1-F12. Examples `ctl_keyboard` and `ctl_commands`.

- Text editing contract: `gates_textbox_copy_text`, `_selection`, `_set_selection`, `_replace_selection`, `_set_read_only`, `_set_max_bytes`, `_set_password`, `_set_undo_limits`, `_can_undo`/`_can_redo`, `_accept_fit`/`_discard_rejected`, `_edit_commit`; `gates_text_edit_reserve`.
- Clipboard boundary `include/gates/clipboard.h` with a Win32 CF_UNICODETEXT provider; Ctrl+C/X/V, Ctrl+Z, Ctrl+Y and Ctrl+Shift+Z; single-line paste policy.
- GATES_EVENT_LIMIT_EXCEEDED with `limit` and `fit_bytes`: an over-limit edit is refused and kept as an offer so the application can ask the person.
- `alt` on `gates_key_event_t`; Ctrl+Alt (AltGr) is never a shortcut.
- ctl_textbox shows a 10-byte field with its question, a password field and a read-only field.

- Typed change notifications: `include/gates/event.h` with TEXT_CHANGED, PREEDIT_CHANGED, VALUE_CHANGED and ACTIVATED, `gates_widget_set_handler`, `gates_widget_notify`, `gates_widget_revision`, `gates_tree_dispatch_events`, `gates_tree_pending_events`; events are reserved before an edit commits, coalesced, delivered at a safe point, and safe against handlers that mutate or destroy nodes.
- `gates_input_take_error` and `gates_input_cancel_pointer`; the Win32 window cancels press/drag on WM_CAPTURECHANGED and WM_CANCELMODE, delivers events after every input message, and cancels an IME composition when application code moves focus.
- One example per control: `ctl_label`, `ctl_button`, `ctl_checkbox`, `ctl_textbox`, `ctl_panel`, `ctl_stack`, `ctl_split`, `ctl_scroll` (see `examples/README.md`).

- IME composition (Phase 3B): `gates_input_preedit`, `gates_input_commit`, `gates_input_preedit_cancel`, `gates_input_composing`, `gates_input_caret_rect`; the textbox draws the preedit inline with an underline and keeps the IME cursor in view.
- Win32 IMM32 adapter: WM_IME_STARTCOMPOSITION/COMPOSITION/ENDCOMPOSITION, result string as the only commit, composition completed before a click or focus loss, composition and candidate windows placed at the caret; examples link `imm32`.
- `gates_textbox_set_text` (returns BUSY while a composition is open).
- `gates_input_result_t` (IGNORED / CONSUMED / FAILED).
- Core intent stated in the README: an interaction layer, not a picture (HTML+CSS-like).

### Changed

- Clicking a button or checkbox now gives it keyboard focus; clicking elsewhere leaves focus where it is (previously any click outside a textbox cleared focus).
- Destroying the focused textbox moves focus to the next control instead of leaving none.

- `gates_input_char` returns `gates_input_result_t` instead of `bool` (IGNORED is 0, so boolean use still works).
- A preedit is displayed at the selection end; moving focus away from a textbox drops its uncommitted preedit.
- The next milestone is "Windows Tool UI 1".

### Deprecated

- `gates_textbox_edit` (mutable edit core): use the safe textbox operations; call `gates_textbox_edit_commit` after raw edits.

### Removed

### Fixed

- Win32 released the mouse capture before routing the button-up event.
- `gates_widget_text` on a textbox returned an unused label field instead of the box's text.
- text_demo no longer updates labels during paint; it follows the textbox through events.

- `gates_input_char` reported an insert that failed on allocation as consumed; it now returns FAILED and leaves the text unchanged.
- `gates_widget_set_text` on a textbox changed a hidden label field instead of the box's text.
- text_demo's mirror label could lag one frame behind the textbox.

### Security
